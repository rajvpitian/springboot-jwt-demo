package com.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.config.JwtTokenUtil;
import com.demo.dao.UserDAO;
import com.demo.model.Address;
import com.demo.model.User;

@Service
public class UserService{
	@Autowired
	private JwtTokenUtil jwtTokenUtil;
	
	@Autowired
	UserDAO userDao;
	
	public List<User> getUsers(){
		return (List<User>)userDao.findAll();
	}
	
	public Optional<User> updateUser(HttpServletRequest request, long userId, String addr){
			String countryName = addr.split(",")[5];
			String stateName = addr.split(",")[7];
			String cityName = addr.split(",")[8];
			
			Optional<User> optional = userDao.findById(userId);
			if(isUserAdmin(request)){
				Address newAddress = new Address();
				newAddress.setCountry(countryName);
				newAddress.setCity(stateName);
				newAddress.setState(cityName);
				List<Address> addrList = new ArrayList<>();
				addrList.add(newAddress);
				optional.ifPresent(user->{
					user.setAddress(addrList);
					userDao.save(user);
				});
			}
			return (Optional<User>) userDao.findById(userId);
	}
	
	private Boolean isUserAdmin(HttpServletRequest request){
		String requestTokenHeader= request.getHeader("Authorization");
		try{
			if(requestTokenHeader!=null && requestTokenHeader.startsWith("Bearer")){
				String jwtToken = requestTokenHeader.substring(7);
				String userName= jwtTokenUtil.getUsernameFromToken(jwtToken);
				long roleId = userDao.findByUsername(userName).getRole().getId();
				if(roleId==2){
					return true;
				}
			}
		} catch(Exception e){
			System.out.println(e.getMessage());
		}
		return false;
	}
}