package com.demo.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.demo.dao.UserDAO;
import com.demo.model.Department;
import com.demo.model.Role;
import com.demo.model.User;
import com.demo.model.UserDTO;

@Service
public class JwtUserDetailsService implements UserDetailsService {
	
	@Autowired
	private UserDAO userDao;

	@Autowired
	private PasswordEncoder bcryptEncoder;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user = userDao.findByUsername(username);
		if (user == null) {
			throw new UsernameNotFoundException("User not found with username: " + username);
		}
		return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(),
				new ArrayList<>());
	}
	
	public User save(UserDTO user) {
		User newUser = new User();
		Role userRole = new Role();
		Department userDepartment = new Department();
		String dept = user.getDepartmentId()+"";
		
		newUser.setUsername(user.getUsername());
		newUser.setPassword(bcryptEncoder.encode(user.getPassword()));
		newUser.setEmail(user.getEmail());
		userRole.setId(user.getRoleId());
		
		if(user.getRoleId()==1){
			userRole.setRolename("EMPLOYEE");
		} else if(user.getRoleId()==2){
			userRole.setRolename("ADMIN");
		} else {
			userRole.setRolename("");
		}
		newUser.setRole(userRole);
		switch(dept){
			case "1":
				userDepartment.setDeptname("ECE");
				break;
			case "2":
				userDepartment.setDeptname("CSE");
				break;
			case "3":
				userDepartment.setDeptname("IT");
				break;
			default :
				userDepartment.setDeptname("");
				break;
		}
		userDepartment.setId(user.getDepartmentId());
		newUser.setDepartment(userDepartment);
		return userDao.save(newUser);
	}
}