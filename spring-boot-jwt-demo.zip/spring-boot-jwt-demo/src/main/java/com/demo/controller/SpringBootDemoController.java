package com.demo.controller;

import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.demo.model.User;
import com.demo.service.UserService;

@RestController
public class SpringBootDemoController {
	
	@Autowired
	UserService userService;
	
	@GetMapping({"/users"})
	public ResponseEntity<?> getUsers() {
		return new ResponseEntity<>(userService.getUsers(),HttpStatus.OK);
	}/* 

	@PutMapping({"/users"})
	public ResponseEntity<?> updateUsers(@RequestParam int userId,@RequestParam String ipAddr) {
		String accessKey = "626053333c5203dcd83c391d63485afb";
		final String uri="http://api.ipstack.com/"+ipAddr+"?access_key="+accessKey;
		RestTemplate restTemplate = new RestTemplate();
		String result = restTemplate.getForObject(uri, String.class);
		System.out.println("RESULT : "+result);
		String countryName = result.split(",")[5];
		String regionName= result.split(",")[7];
		String cityName= result.split(",")[8];
		Address newAddress = new Address();
		newAddress.setCity(cityName);
		newAddress.setState(regionName);
		newAddress.setCountry(countryName);
		Optional<User> user = userService.getUserById(userId);
		return new ResponseEntity<>("Empty",HttpStatus.OK);
	} */
	
	@PutMapping({"/users"})
	public ResponseEntity<?> updateUser(HttpServletRequest request,@RequestParam long userId,@RequestParam String ipAddr) {
		String accessKey = "626053333c5203dcd83c391d63485afb";
		final String uri="http://api.ipstack.com/"+ipAddr+"?access_key="+accessKey;
		RestTemplate restTemplate = new RestTemplate();
		String result = restTemplate.getForObject(uri, String.class);
		Optional<User> user = userService.updateUser(request,userId,result);
		if(!user.isPresent()){
			return new ResponseEntity<>(user,HttpStatus.OK);
		} else {
			return new ResponseEntity<>("Message - User not having sufficient role",HttpStatus.OK);
		}
		
	}
	
}